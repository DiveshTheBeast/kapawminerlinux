./kawpowminer -P stratum+tcp://wallet.worker/password@rvn-eu1.nanopool.org:12222

